﻿namespace Troup_Oddnumgen
{
    partial class Oddgenform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.genlabel1 = new System.Windows.Forms.Label();
            this.genlabel2 = new System.Windows.Forms.Label();
            this.genlabel3 = new System.Windows.Forms.Label();
            this.genlabel4 = new System.Windows.Forms.Label();
            this.genlabel5 = new System.Windows.Forms.Label();
            this.genbutton1 = new System.Windows.Forms.Button();
            this.genbutton2 = new System.Windows.Forms.Button();
            this.gentextBox3 = new System.Windows.Forms.TextBox();
            this.gentextBox1 = new System.Windows.Forms.TextBox();
            this.genlistBox2 = new System.Windows.Forms.ListBox();
            this.saveRandomnumber = new System.Windows.Forms.SaveFileDialog();
            this.openRandomnumber = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // genlabel1
            // 
            this.genlabel1.AutoSize = true;
            this.genlabel1.Location = new System.Drawing.Point(39, 9);
            this.genlabel1.Name = "genlabel1";
            this.genlabel1.Size = new System.Drawing.Size(139, 13);
            this.genlabel1.TabIndex = 0;
            this.genlabel1.Text = "Generate Random Numbers";
            // 
            // genlabel2
            // 
            this.genlabel2.AutoSize = true;
            this.genlabel2.Location = new System.Drawing.Point(200, 60);
            this.genlabel2.Name = "genlabel2";
            this.genlabel2.Size = new System.Drawing.Size(203, 13);
            this.genlabel2.TabIndex = 1;
            this.genlabel2.Text = "Number of Random Numbers to Generate";
            // 
            // genlabel3
            // 
            this.genlabel3.AutoSize = true;
            this.genlabel3.Location = new System.Drawing.Point(39, 179);
            this.genlabel3.Name = "genlabel3";
            this.genlabel3.Size = new System.Drawing.Size(72, 13);
            this.genlabel3.TabIndex = 2;
            this.genlabel3.Text = "Odd Numbers";
            // 
            // genlabel4
            // 
            this.genlabel4.AutoSize = true;
            this.genlabel4.Location = new System.Drawing.Point(316, 179);
            this.genlabel4.Name = "genlabel4";
            this.genlabel4.Size = new System.Drawing.Size(125, 13);
            this.genlabel4.TabIndex = 3;
            this.genlabel4.Text = "Generated Odd Numbers";
            // 
            // genlabel5
            // 
            this.genlabel5.AutoSize = true;
            this.genlabel5.Location = new System.Drawing.Point(607, 179);
            this.genlabel5.Name = "genlabel5";
            this.genlabel5.Size = new System.Drawing.Size(91, 13);
            this.genlabel5.TabIndex = 4;
            this.genlabel5.Text = "Odd Number Sum";
            // 
            // genbutton1
            // 
            this.genbutton1.Location = new System.Drawing.Point(42, 38);
            this.genbutton1.Name = "genbutton1";
            this.genbutton1.Size = new System.Drawing.Size(119, 89);
            this.genbutton1.TabIndex = 5;
            this.genbutton1.Text = "Click to Generate Random Numbers";
            this.genbutton1.UseVisualStyleBackColor = true;
            this.genbutton1.Click += new System.EventHandler(this.genbutton1_Click);
            // 
            // genbutton2
            // 
            this.genbutton2.Location = new System.Drawing.Point(42, 195);
            this.genbutton2.Name = "genbutton2";
            this.genbutton2.Size = new System.Drawing.Size(188, 129);
            this.genbutton2.TabIndex = 6;
            this.genbutton2.Text = "Click to Display Odd Numbers Generated and Sum of Odd Numbers";
            this.genbutton2.UseVisualStyleBackColor = true;
            this.genbutton2.Click += new System.EventHandler(this.genbutton2_Click);
            // 
            // gentextBox3
            // 
            this.gentextBox3.Location = new System.Drawing.Point(607, 213);
            this.gentextBox3.Multiline = true;
            this.gentextBox3.Name = "gentextBox3";
            this.gentextBox3.Size = new System.Drawing.Size(91, 29);
            this.gentextBox3.TabIndex = 7;
            // 
            // gentextBox1
            // 
            this.gentextBox1.Location = new System.Drawing.Point(422, 60);
            this.gentextBox1.Name = "gentextBox1";
            this.gentextBox1.Size = new System.Drawing.Size(100, 20);
            this.gentextBox1.TabIndex = 8;
            // 
            // genlistBox2
            // 
            this.genlistBox2.FormattingEnabled = true;
            this.genlistBox2.Location = new System.Drawing.Point(319, 195);
            this.genlistBox2.Name = "genlistBox2";
            this.genlistBox2.Size = new System.Drawing.Size(153, 160);
            this.genlistBox2.TabIndex = 9;
            // 
            // openRandomnumber
            // 
            this.openRandomnumber.FileName = "openFileDialog1";
            // 
            // Oddgenform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 361);
            this.Controls.Add(this.genlistBox2);
            this.Controls.Add(this.gentextBox1);
            this.Controls.Add(this.gentextBox3);
            this.Controls.Add(this.genbutton2);
            this.Controls.Add(this.genbutton1);
            this.Controls.Add(this.genlabel5);
            this.Controls.Add(this.genlabel4);
            this.Controls.Add(this.genlabel3);
            this.Controls.Add(this.genlabel2);
            this.Controls.Add(this.genlabel1);
            this.Name = "Oddgenform";
            this.Text = "Odd Number Generator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label genlabel1;
        private System.Windows.Forms.Label genlabel2;
        private System.Windows.Forms.Label genlabel3;
        private System.Windows.Forms.Label genlabel4;
        private System.Windows.Forms.Label genlabel5;
        private System.Windows.Forms.Button genbutton1;
        private System.Windows.Forms.Button genbutton2;
        private System.Windows.Forms.TextBox gentextBox3;
        private System.Windows.Forms.TextBox gentextBox1;
        private System.Windows.Forms.ListBox genlistBox2;
        private System.Windows.Forms.SaveFileDialog saveRandomnumber;
        private System.Windows.Forms.OpenFileDialog openRandomnumber;
    }
}

