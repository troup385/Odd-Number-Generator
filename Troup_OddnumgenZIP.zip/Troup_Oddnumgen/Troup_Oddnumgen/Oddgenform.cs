﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Troup_Oddnumgen
{
    public partial class Oddgenform : Form
    {

        public Oddgenform()
        {
            InitializeComponent();
        }

        private void genbutton1_Click(object sender, EventArgs e)
        {
            //Create a random number
            genlistBox2.Items.Clear();
            Random generator = new Random();
            //outfputFile is just the name of the StreamWriter
            StreamWriter outputFile;
            try
            {    //Prompt the user to show a save as file dialog box.  If the user presses the OK button then the code inside is executed.
                if (saveRandomnumber.ShowDialog() == DialogResult.OK)
                {

                    //Tells the system to save the file as whatever the user typed in inside of the Save As dialog for the filename

                    outputFile = File.CreateText(saveRandomnumber.FileName);
                    int numInts = int.Parse(gentextBox1.Text);

                    //This is just the counter for the while loop -- you could use a for loop
                    int counter = 1;
                    //While the counter is less than or equal to 10 keep looping
                    while (counter <= numInts)
                    {
                        //Generate a random number between 1 and 100 and store it in the variable randomNum
                        int randomNum = generator.Next(1, 101);
                        outputFile.WriteLine(randomNum);
                        //Increment the counter
                        counter++;
                    } //end while

                    outputFile.Close();

                } //end if statement

            }
            catch (Exception ex) //displays error message if a non integer is entered.
            {
                MessageBox.Show("You entered a bad value");
            }
            
        }

        private void genbutton2_Click(object sender, EventArgs e)
        {
            StreamReader inputFile; // Creating a file to store data 
            int numberFromFile; //declaring variable
            if (openRandomnumber.ShowDialog() == DialogResult.OK) //Prompt the user to show a save as file dialog box.  If the user presses the OK button then the code inside is executed.
            {
                inputFile = File.OpenText(openRandomnumber.FileName); //Tells the system to save the file as whatever the user typed in inside of the Save As dialog for the filename
                while (!inputFile.EndOfStream) 
                {
                    numberFromFile = int.Parse(inputFile.ReadLine());
                    if (numberFromFile % 2 != 0) //code to pick out the odd numbers to display in the listbox
                    {
                        genlistBox2.Items.Add(numberFromFile);// add
                    }
                }
                inputFile.Close();//closes file created

                int sum = 0; //variable declared for sum of off numbers 
                int counter = 0; //Initialize the counter for the loop -- It MUST begin at zero since the number of items in the listbox always begins at zero
                while (counter < genlistBox2.Items.Count)//determines when to stop counting
                {
                    sum = sum + int.Parse(genlistBox2.Items[counter].ToString());
                    counter++;//code to add odd numbers in the listbox 
                }
                gentextBox3.Text = sum.ToString();//display total in textbox
            }











        }
    }
}
